<?php
/**
 * The Template for displaying all single posts.
 *
 * @package blm_basic
 */

get_header(); ?>

<div id="main">
	
	<section id="content">
		
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			
			<h1 class="titles"><?php the_title(); ?></h1>
			<?php echo get_avatar( get_the_author_meta( 'ID' ), 64 );?>
			<p>Posted By: <a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>"><?php the_author(); ?></a></p>
			<?php the_date('D M  Y'); ?>
			<?php the_content(); ?>

			<img src="http://localhost:8888/kim_sjoblad/wp-content/uploads/2014/05/kim-sig.png" class="signature" alt="">
						
			<?php get_template_part( 'inc/meta' ); ?>

			
			<nav class="post-navigation">
				<div class="nav-previous"><?php previous_post_link( '&laquo; %link' ); ?></div>
				<div class="nav-next"><?php next_post_link( '%link &raquo;' ); ?></div>
			</nav>
			
		</article>


	  <?php comments_template(); ?>
	
	  <?php endwhile; endif; ?>
	
	</section>
	
<?php get_sidebar(); ?>

</div><!-- end of main div -->

<?php get_footer(); ?>