<?php
/**
 * Template Name: Home Page
 *
 * @package blm_basic
 */

get_header(); ?>



<div id="main">
	
	<section id="content">

		<div class="video-home">
			<a href=""><img src="http://placehold.it/800x465"></a>
		</div>
		<div class="fertility-home home-box">
			<a href=""><img src="http://localhost:8888/kim_sjoblad/wp-content/uploads/2014/05/fertility-home.jpg"></a>
		</div>
		<div class="pregnancy-home home-box">
			<a href=""><img src="http://localhost:8888/kim_sjoblad/wp-content/uploads/2014/05/pregHomePageAd.jpg" alt=""></a>
		</div>
		
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			
		<article <?php post_class() ?> id="post-<?php the_ID(); ?>">
			
			
			
			<?php the_content(); ?>
			
		</article>
		
		<?php endwhile; endif; ?>
		
	</section><!-- #content -->

<?php get_sidebar(); ?>

</div><!-- #main -->



<?php get_footer(); ?>