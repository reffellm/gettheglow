<?php
/**
 * Template Name: About Page
 *
 * @package blm_basic
 */

get_header(); ?>

<div id="main">
	
	<section id="about-content">
		
		
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			
		<article <?php post_class() ?> id="post-<?php the_ID(); ?>">
			
			<h1 class="titles"><?php the_title(); ?></h1>
			
			<?php the_content(); ?>

			<img src="http://localhost:8888/kim_sjoblad/wp-content/uploads/2014/05/kim-sig.png" class="signature" alt="">
			
		</article>
		
		<?php endwhile; endif; ?>
		
	</section><!-- #content -->
	<div class="about-optin">
		
	</div>

	<div class="pro-bio">
		<h3><strong>Professional Bio</strong></h3>
		<p>Kim Sjoblad is a Certified Nutritional Practitioner and Fertility Coach, and the creator of the The Fertility Glow and The Pregnacy Glow programs. Kim created these programs out of her passion for educating and coaching women on the many holistic ways to improve their overall health and to provide them with options for preconception. Within her teachings, she has also connected women and couples with the best holistic approaches to achieve conception and to sustain a long, healthy life.
Kim specializes in fertility, pregnancy and women’s hormonal conditions. She has knowledge and experience working with couples who have fertility concerns, and has created her own unique fertility program customized to the needs of both those undergoing IVF procedures and those wishing to work with natural fertility methods. Her practical and realistic, programs inspire women to take charge of their health and happiness by adopting
a whole foods diet, improving their lifestyle practices, and learning to live and love like they really mean it.</p>
	</div>

</div><!-- #main -->

<?php get_footer(); ?>