<?php
/**
 * The template for displaying the footer.
 * 
 * @package blm_basic
 */
?>
</div> <!-- end of content wrapper  -->
	<footer id="footer">
	<ul class="footer-social">
		<li><a href=""><img src="http://localhost:8888/kim_sjoblad/wp-content/uploads/2014/05/twitter.png" alt=""></a></li>
		<li><a href=""><img src="http://localhost:8888/kim_sjoblad/wp-content/uploads/2014/05/facebook.png" alt=""></a></li>
		<li><a href=""><img src="http://localhost:8888/kim_sjoblad/wp-content/uploads/2014/05/google.png" alt=""></a></li>
		<li><a href=""><img src="http://localhost:8888/kim_sjoblad/wp-content/uploads/2014/05/youtube.png" alt=""></a></li>
		<li><a href=""><img src="http://localhost:8888/kim_sjoblad/wp-content/uploads/2014/05/pinterest.png" alt=""></a></li>
	</ul>
	<?php wp_nav_menu( array( 'theme_location' => 'footer', 'depth' => 3 ) ); ?>
		<p class="copyright">Copyright &copy; <?php bloginfo( 'name' ); ?> <?php echo date( 'Y' ); ?> get your glow. All rights reserved. <a href="">Disclaimer</a> / <a href="">Privacy Policy</a> || Made with  &hearts;  by <a href="http://margreffell.com">Marg Reffell.</a></p>
	</footer>
	
</div><!-- !wrap -->
<?php wp_footer(); ?>

<script>
	var $ = jQuery;

	$(function(){
		var stickyRibbonTop = $('.site-header').offset().top;
		  
		$(window).scroll(function(){

			if( $(window).scrollTop() > stickyRibbonTop ) {
					$('.site-header').addClass('branding');
					$('.banner img').addClass('banner-margin');
			} else {
					$('.site-header').removeClass('branding');
					$('.banner img').removeClass('banner-margin');
			}

		});
	});
</script>
</body>
</html>